from __future__ import unicode_literals

from django.apps import AppConfig


class NGoldConfig(AppConfig):
    name = 'n_gold'
