from flask import Flask, render_template, request, redirect, session, flash
app = Flask(__name__)
app.secret_key = 'secrecy1234'
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods = ['POST'])
def process():
    errors = False
    if len(request.form['name']) == 0:
        flash('Name cannot be empty!')
        errors = True
    if len(request.form['comment']) == 0:
        flash('Comment cannot be empty!')
        errors = True
    if len(request.form['comment']) > 120:
        flash('Comment cannot be longer than 120 characters')
        errors = True
    if errors:
        return redirect('/')

    session['submitted_info'] = request.form
    return redirect('/result')

@app.route('/result')
def result():
    return render_template('result.html', a=request.form['name'], b=request.form['location'], c=request.form['language'], d=request.form['comment'])
app.run(debug=True)
